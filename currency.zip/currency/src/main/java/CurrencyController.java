package com.currency.currency;

import org.springframework.web.bind.annotation.*;

@RestController
public class CurrencyController {

    @GetMapping("/convert")
    public String convert(@RequestParam double rupees) {

        double dollars = rupees / 75;

        return "Rupees: " + rupees + " = Dollars: " + dollars;
    }
}